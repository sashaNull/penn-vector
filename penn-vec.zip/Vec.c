#include "./Vec.h"
#include "./panic.h"
#include <stdlib.h>

Vec vec_new(size_t initial_capacity, ptr_dtor_fn ele_dtor_fn) {
  // TODO: implement me
}

// TODO: the rest of the vector functions

